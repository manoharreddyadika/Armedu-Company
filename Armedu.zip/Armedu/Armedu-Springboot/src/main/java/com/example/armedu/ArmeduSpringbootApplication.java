package com.example.armedu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArmeduSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArmeduSpringbootApplication.class, args);
	}

}
