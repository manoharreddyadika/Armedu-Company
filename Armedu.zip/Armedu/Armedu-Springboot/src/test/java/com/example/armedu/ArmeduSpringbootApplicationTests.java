package com.example.armedu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArmeduSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
